$(function(){
$('button[title]').tooltip();
});